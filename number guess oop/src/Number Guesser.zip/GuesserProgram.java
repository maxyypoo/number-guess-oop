//Doga Akpinaroglu

import java.util.Scanner;



public class GuesserProgram {

    
    static public boolean shouldPlayAgain ()
    {
        Scanner input = new Scanner(System.in);
        boolean play = true;
        char goAgain;
        boolean wrongChar = true;

        System.out.print("Would you like to go again? (y/n): ");
        goAgain = input.next().charAt(0);
        
        do
        {
        if(goAgain == 'y')
        {
            play = true;
        }
        else if (goAgain == 'n')
        {
            play = false;
        }
        else
        {
            wrongChar = false;
        }
        } while (wrongChar == false);

        return play;
    }

    public static void play ()
    {

        int min = 1;
        int max = 100;
        char userGuess;
        boolean userGuessCorrect = false;
        Scanner input = new Scanner(System.in);


        NumberGuesser guess = new NumberGuesser(min, max);

        System.out.println ("Please make a guess between 1 and 100");
        while (userGuessCorrect == false)
        {
            System.out.print("Is the number you guessed: " + guess.getCurrentGuess() + "? (h for higher, l for lower, c for correct): ");
            userGuess = input.next().charAt(0);

            if (userGuess == 'h')
            {
                guess.higher();
            }
            else if (userGuess == 'l')
            {
                guess.lower();
            }
            else if (userGuess == 'c')
            {
                userGuessCorrect = true;
                guess.reset();
            }
            else
            {
                while (userGuess != 'h' && userGuess != 'l' && userGuess != 'c')
                {
                    System.out.print("Please use appropriate syntax,h for higher, l for lower, c for correct ");
                    userGuess = input.next().charAt(0);
                }
            }
        }
    }
    
    public static void main (String args[])
    {
        do 
        {
            play();
        }while (shouldPlayAgain());

        
    }
}
