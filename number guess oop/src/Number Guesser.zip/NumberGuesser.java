//Doga Akpinaroglu
public class NumberGuesser 
{
    private
    int lower;
    private
    int upper;
    private
    int calledUpper;
    private
    int calledLower;


    private int getMidPoint (int lower, int upper)
    {
        int midPoint = (lower + upper)/2;
        if (lower == upper - 1 && upper == calledUpper)
        {
            return 100;
        }
        if (lower == calledLower && upper == lower + 1)
        {
            return 1;
        }
        return midPoint;

    }


    public NumberGuesser (int lowerBound, int upperBound)
    {
        lower = lowerBound;
        upper = upperBound;
        calledLower = lowerBound;
        calledUpper = upperBound;
    }

    public void higher ()
    {
        lower = getMidPoint(lower, upper);
    }
    public void lower()
    {
        upper = getMidPoint(lower, upper);
    }

    int getCurrentGuess ()
    {
        return getMidPoint(lower, upper);
    }
    void reset ()
    {
        lower = calledLower;
        upper = calledUpper;
    }

}